import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Map_Screen extends StatefulWidget {
  @override
  _Map_ScreenState createState() => _Map_ScreenState();
}

class _Map_ScreenState extends State<Map_Screen> {
  LatLng _markerPosition = LatLng(15.9707, 120.5838); // Default location: Manila
  TextEditingController _locationController = TextEditingController();
  TextEditingController _cityProvController = TextEditingController();

  // Function to update location info
  Future<void> _getLocationInfo(double lat, double lon) async {
    final String apiKey = 'pk.5f2137974ab407777980a5122a82a0f4'; // Replace with your LocationIQ API key
    final String url =
        'https://us1.locationiq.com/v1/reverse.php?key=$apiKey&lat=$lat&lon=$lon&format=json';

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      setState(() {
        _locationController.text =
            '${data['address']['city']}, ${data['address']['state_district']}, ${data['address']['state']}';
            _cityProvController.text =
            '${data['display_name']}';
      });
    } else {
      print('Failed to load location data');
    }
  }

  // Function to handle marker drag
  void _onMarkerDragEnd(LatLng position) {
    setState(() {
      _markerPosition = position;
    });
    _getLocationInfo(position.latitude, position.longitude);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Location IQ Demo'),
      ),
      body: Column(
        children: [
          // Map Widget
          Container(
            height: 400,
            width: double.infinity,
            child: Stack(
              children: [
                FlutterMap(
                options: MapOptions(
                  center: _markerPosition,
                  zoom: 12.0,
                  onTap: (tapPosition, point) {
                    _getLocationInfo(point.latitude, point.longitude);
                  },
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                    subdomains: ['a', 'b', 'c'],
                  ),
                ],
              ),
              Align(
                alignment: Alignment.center,
                child: Icon(
                  Icons.location_on,
                  size: 50,
                  color: Colors.red,
                ),
              ),
              ]
            ),
          ),
          // TextField for displaying location info
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextField(
                  controller: _locationController,
                  decoration: InputDecoration(
                    labelText: 'City, Province',
                    border: OutlineInputBorder(),
                  ),
                ),
                TextField(
                  controller: _cityProvController,
                  decoration: InputDecoration(
                    labelText: 'City, Province',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
